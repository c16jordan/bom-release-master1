<?php
  $nav_selected = "REPORTS";
  $left_buttons = "YES";
  $left_selected = "";

  include("./nav.php");
  
 ?>
 
 <div class="right-content">
    <div class="container">

      <h3 style = "color: #01B0F1;">Reports</h3>

    </div>
</div>

<?php include("./footer.php"); ?>
