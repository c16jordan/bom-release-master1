# bom
# Connecting to a MySQL database, pulling releases from a BOM table and formatting the data to a Google Gantt Chart.
