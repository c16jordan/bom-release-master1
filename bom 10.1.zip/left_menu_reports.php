<div id="menu-left">

	<a href="reports_pi_chart.php">
		<div <?php if($left_selected == "REPORTS")
		{ echo 'class="menu-left-current-page"'; } ?>>
		<!-- http://www.clker.com/cliparts/4/e/5/a/1206557176743993576mcol_pie_chart.svg.hi.png pichart -->
		<img src="./images/piechart.png" alt='Pie Chart clip art'>
		<br/>BOM Reports<br/>
		<br/><div style="font-size:0.6em ;margin-top: -25px; margin-bottom: 0px"><a href="http://www.clker.com/cliparts/4/e/5/a/1206557176743993576mcol_pie_chart.svg.hi.png" >Image Source</a></div><br/></div>
	</a>
	
	<a href="reports_bar_chart.php">
		<div <?php if($left_selected == "REPORTS")
		{ echo 'class="menu-left-current-page"'; } ?>>
	   <!-- http://www.clker.com/cliparts/J/L/3/D/K/k/bar-chart-hi.png -->
		<img src="./images/barchart.png" alt='Pie Chart clip art'>
		<br/>Bar Chart<br/>
		<br/><div style="font-size:0.6em ;margin-top: -25px; margin-bottom: 0px"><a href="http://www.clker.com/cliparts/J/L/3/D/K/k/bar-chart-hi.png">Image Source</a></div><br/></div>
		</div>
	</a>
  
</div>
