<?php
  $nav_selected = "LIST";
  $left_buttons = "NO";
  $left_selected = "";

  include("./nav.php");
  
 ?>

 <div class="right-content">
    <div class="container">

      <h3 style = "color: #01B0F1;">List (TO BE DONE LATER)</h3>


    </div>
</div>

<?php include("./footer.php"); ?>
