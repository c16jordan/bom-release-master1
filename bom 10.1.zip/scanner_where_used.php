<?php
  $nav_selected = "SCANNER";
  $left_buttons = "YES";
  $left_selected = "WHEREUSED";

  include("./nav.php");
  
 ?>

 <div class="right-content">
    <div class="container">

      <h3 style = "color: #01B0F1;">Scanner --> Where Used </h3>

    </div>
</div>

<?php include("./footer.php"); ?>
